const $ = id => document.getElementById(id);

let expression = "";
let memory = 0;
let lastAnswer = 0;
let angleMode = "DEG";
let justCalculated = false;

const panel = $("scientificPanel");
const toggle = $("toggleScience");

toggle.addEventListener("click", () => {
    const isOpen = panel.classList.toggle("open");
    toggle.textContent = isOpen ? "Scientific ⌃" : "Scientific ⌄";
    toggle.setAttribute("aria-expanded", String(isOpen));
});

$("angleMode").addEventListener("click", () => {
    angleMode = angleMode === "DEG" ? "RAD" : "DEG";
    $("angleMode").textContent = angleMode;
});

function update() {
    $("expression").textContent = expression || "Ready";
}

function insert(value) {
    if (justCalculated) {
        if (/^[0-9.]$/.test(value) || value === "pi" || value === "e") {
            expression = "";
        }
        justCalculated = false;
    }

    expression += value;
    update();
}

function evaluateExpression(source) {
    const toRad = x => angleMode === "DEG" ? x * Math.PI / 180 : x;
    const fromRad = x => angleMode === "DEG" ? x * 180 / Math.PI : x;

    return math.evaluate(source, {
        sin: x => Math.sin(toRad(x)),
        cos: x => Math.cos(toRad(x)),
        tan: x => Math.tan(toRad(x)),
        asin: x => fromRad(Math.asin(x)),
        acos: x => fromRad(Math.acos(x)),
        atan: x => fromRad(Math.atan(x)),
        sqrt: Math.sqrt,
        cbrt: Math.cbrt,
        abs: Math.abs,
        log: Math.log10,
        ln: Math.log,
        mod: (a, b) => a % b,
        pi: Math.PI,
        e: Math.E,
        ans: lastAnswer
    });
}

function calculate() {
    if (!expression.trim()) return;

    try {
        const oldExpression = expression;
        let answer = evaluateExpression(expression);

        if (typeof answer !== "number" || !Number.isFinite(answer)) {
            throw new Error("Invalid result");
        }

        if (Math.abs(answer) < 1e-12) answer = 0;

        lastAnswer = answer;
        $("history").textContent = oldExpression + " =";
        $("result").textContent = Number(answer.toPrecision(12)).toString();
        expression = String(answer);
        justCalculated = true;
        update();
    } catch {
        $("result").textContent = "Error";
        $("expression").textContent = "Check your calculation";
        justCalculated = false;
    }
}

function clearAll() {
    expression = "";
    justCalculated = false;
    $("result").textContent = "0";
    $("history").textContent = "";
    update();
}

document.querySelector(".calculator").addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button) return;

    if (button === toggle || button.id === "angleMode") return;

    const value = button.dataset.insert;
    const action = button.dataset.action;

    if (value !== undefined) {
        insert(value);
        return;
    }

    switch (action) {
        case "clear":
            clearAll();
            break;

        case "equals":
            calculate();
            break;

        case "sign":
            if (expression) {
                expression = "-(" + expression + ")";
                justCalculated = false;
                update();
            }
            break;

        case "percent":
            if (expression) {
                expression = "(" + expression + ")/100";
                justCalculated = false;
                update();
            }
            break;

        case "memory-clear":
            memory = 0;
            $("history").textContent = "Memory cleared";
            break;

        case "memory-recall":
            insert(String(memory));
            break;

        case "memory-add":
            try {
                memory += evaluateExpression(expression || "0");
                $("history").textContent = "Added to memory";
            } catch {
                $("history").textContent = "Invalid expression";
            }
            break;
    }
});

document.addEventListener("keydown", event => {
    if (/^[0-9.]$/.test(event.key)) {
        insert(event.key);
    } else if (["+", "-", "*", "/", "^", "(", ")"].includes(event.key)) {
        insert(event.key);
    } else if (event.key === "Enter" || event.key === "=") {
        event.preventDefault();
        calculate();
    } else if (event.key === "Backspace") {
        expression = expression.slice(0, -1);
        justCalculated = false;
        update();
    } else if (event.key === "Escape") {
        clearAll();
    }
});